package com.example.proba

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputLayout

class CurrencyViewHolder(inflater: LayoutInflater, parent: ViewGroup) :
    RecyclerView.ViewHolder(inflater.inflate(R.layout.item_currency, parent, false)) {
    private val currencyText = itemView.findViewById<TextView>(R.id.currencyText)
    private val textField = itemView.findViewById<TextInputLayout>(R.id.textField)
    private val flag = itemView.findViewById<ImageView>(R.id.flag)

    fun bind(item: Currency, clickListener: (name: Currency) -> Unit) {
        currencyText.text = item.name
        textField.hint = item.value.toString()
        flag.setBackgroundResource(item.imageRes)

        currencyText.setOnClickListener {
            clickListener(item)
        }
    }
}